document.addEventListener("DOMContentLoaded", function () {
    const dropArea = document.getElementById("drop-area");
    const fileInput = document.getElementById("fileInput");
    const browseBtn = document.getElementById("browseBtn");
    const uploadBtn = document.getElementById("uploadBtn");
    const progressBar = document.getElementById("progressBar");
    const filePreview = document.getElementById("file-preview");

    let files = [];

    // Drag & Drop Feature
    dropArea.addEventListener("dragover", (event) => {
        event.preventDefault();
        dropArea.style.background = "#333";
    });

    dropArea.addEventListener("dragleave", () => {
        dropArea.style.background = "transparent";
    });

    dropArea.addEventListener("drop", (event) => {
        event.preventDefault();
        dropArea.style.background = "transparent";
        files = event.dataTransfer.files;
        updateFilePreview();
    });

    // File Selection via Browse Button
    browseBtn.addEventListener("click", () => {
        fileInput.click();
    });

    fileInput.addEventListener("change", () => {
        files = fileInput.files;
        updateFilePreview();
    });

    // Upload Functionality
    uploadBtn.addEventListener("click", () => {
        if (files.length === 0) {
            alert("No file selected!");
            return;
        }

        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("file", files[i]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/upload", true);

        xhr.upload.onprogress = (event) => {
            if (event.lengthComputable) {
                const percent = (event.loaded / event.total) * 100;
                progressBar.value = percent;
            }
        };

        xhr.onload = () => {
            if (xhr.status === 200) {
                alert("Upload complete!");
                progressBar.value = 0;
                filePreview.innerHTML = "";
            } else {
                alert("Upload failed!");
            }
        };

        xhr.send(formData);
    });

    // Function to update file preview
    function updateFilePreview() {
        filePreview.innerHTML = "";
        for (let i = 0; i < files.length; i++) {
            filePreview.innerHTML += `<p>${files[i].name} (${(files[i].size / 1024).toFixed(2)} KB)</p>`;
        }
    }
});
