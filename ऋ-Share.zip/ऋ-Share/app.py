from flask import Flask, request, render_template, send_from_directory, redirect, url_for
import os
import datetime
import socket

app = Flask(__name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'templates', 'upload')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.template_filter('datetimeformat')
def datetimeformat(value):
    return datetime.datetime.fromtimestamp(value).strftime('%Y-%m-%d %H:%M:%S')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send')
def send_page():
    return render_template('send.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return "No file part"
    file = request.files['file']
    if file.filename == '':
        return "No selected file"
    file.save(os.path.join(UPLOAD_FOLDER, file.filename))
    return redirect(url_for('view_files'))

@app.route('/files')
def view_files():
    files = os.listdir(UPLOAD_FOLDER)
    file_data = []
    
    for file in files:
        file_path = os.path.join(UPLOAD_FOLDER, file)
        if os.path.isfile(file_path):  # Ensure it's a file, not a directory
            file_data.append({
                "name": file,
                "date": os.path.getmtime(file_path)  # Last modified timestamp
            })
    
    # Sort files by date (latest first)
    file_data.sort(key=lambda x: x["date"], reverse=True)

    return render_template('files.html', files=file_data)

@app.route('/files/<filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

if __name__ == '__main__':
    host_ip = socket.gethostbyname(socket.gethostname())  # Get local machine's IPv4 address
    print(f"Dashboard link: http://{host_ip}")
    app.run(host='0.0.0.0', port=80, debug=True)
